from flask import Flask, request, jsonify, render_template
import speech_recognition as sr
import openai

app = Flask(__name__)

# OpenAI API key setup
openai.api_key = "sk-45IP-VkQDilefrnypJShbdY8V8RHqrgI8TSptnR7C6T3BlbkFJnSfsZ_LmNi7EO3GD36XGnnVngFgRtMClRc6m5EVdwA"

@app.route('/')
def index():
    return render_template('index.html')  # Renders an HTML page for interaction

from pydub import AudioSegment

@app.route('/record', methods=['POST'])
def record():
    try:
        # Receive the audio file from the frontend
        audio_file = request.files['audio']
        audio_path = 'temp_audio.wav'
        audio_file.save('temp_audio_original')

        # Convert to PCM WAV using PyDub
        sound = AudioSegment.from_file('temp_audio_original')
        sound.export(audio_path, format='wav')

        # Recognize speech using SpeechRecognition
        recognizer = sr.Recognizer()
        with sr.AudioFile(audio_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)

        return jsonify({"text": text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

import openai

@app.route('/confirm', methods=['POST'])
def confirm():
    try:
        user_text = request.json.get("text")
        if not user_text:
            return jsonify({"error": "No text provided"}), 400

        # Pass the confirmed text to ChatGPT
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # or "gpt-4"
            messages=[{"role": "user", "content": user_text}]
        )
        chat_response = response.choices[0].message["content"]
        return jsonify({"response": chat_response})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
