import os
from flask import Flask, render_template, request, redirect, url_for, send_file
import qrcode
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from PyPDF2 import PdfWriter

app = Flask(__name__)

# Configuration
UPLOAD_FOLDER = 'static/qr_codes'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def generate_qr_code(data):
    """Generate a QR code from the provided data."""
    qr = qrcode.QRCode(
        version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4
    )
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    return img

def create_password_protected_pdf(image_path, output_pdf_path, password):
    """Create a password-protected PDF from the QR code image."""
    packet = BytesIO()
    c = canvas.Canvas(packet, pagesize=letter)
    c.drawImage(image_path, 100, 500, 200, 200)  # Position and size of the QR code
    c.save()

    # Create a PDF writer and set the password
    packet.seek(0)
    pdf_writer = PdfWriter()
    pdf_writer.append(packet)
    pdf_writer.encrypt(password)

    with open(output_pdf_path, "wb") as output_file:
        pdf_writer.write(output_file)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        data = request.form.get('url') or request.files.get('file')
        password = request.form.get('password')

        if data and password:
            if hasattr(data, 'filename'):  # File upload
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], data.filename)
                data.save(file_path)
                qr_data = f"File: {file_path}"
            else:  # URL
                qr_data = data

            qr_code_img = generate_qr_code(qr_data)
            qr_code_path = os.path.join(app.config['UPLOAD_FOLDER'], 'qr_code.png')
            qr_code_img.save(qr_code_path)

            # Create password-protected PDF
            pdf_path = os.path.join(app.config['UPLOAD_FOLDER'], 'qr_code.pdf')
            create_password_protected_pdf(qr_code_path, pdf_path, password)

            return render_template('display.html', qr_code_url=url_for('static', filename='qr_codes/qr_code.png'), pdf_url=pdf_path)

    return render_template('index.html')

@app.route('/download/<path:filename>')
def download_file(filename):
    return send_file(filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
