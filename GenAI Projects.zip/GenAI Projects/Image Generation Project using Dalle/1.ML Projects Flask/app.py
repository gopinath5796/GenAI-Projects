import os
from flask import Flask, render_template, request
import openai
import requests  # Import requests library

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/'

# Set your OpenAI API key
openai.api_key = "sk-45IP-VkQDilefrnypJShbdY8V8RHqrgI8TSptnR7C6T3BlbkFJnSfsZ_LmNi7EO3GD36XGnnVngFgRtMClRc6m5EVdwA"

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        prompt = request.form["prompt"]
        try:
            # Generate an image using DALL-E
            response = openai.Image.create(
                prompt=prompt,
                n=1,
                size="1024x1024"
            )
            image_url = response['data'][0]['url']

            # Download the image and save it in the static folder
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], "generated_image.png")
            img_data = requests.get(image_url).content  # Fetch the image data
            with open(image_path, "wb") as handler:
                handler.write(img_data)  # Save the image locally

            return render_template("index.html", image_path=image_path, prompt=prompt)
        except Exception as e:
            return render_template("index.html", error=str(e))

    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)
