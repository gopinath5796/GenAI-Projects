from flask import Flask, request, render_template, send_file, redirect, url_for
import qrcode
import os
import io
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Folder for saving QR codes
UPLOAD_FOLDER = "static/qr_codes"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate_qr", methods=["POST"])
def generate_qr():
    if "file" not in request.files and not request.form.get("link"):
        return "No file or link provided!", 400

    qr_data = ""
    filename = ""

    # Handle file upload
    uploaded_file = request.files.get("file")
    if uploaded_file and uploaded_file.filename != "":
        filename = secure_filename(uploaded_file.filename)
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        uploaded_file.save(file_path)
        qr_data = file_path
    else:
        # Handle link input
        qr_data = request.form.get("link")
        if not qr_data:
            return "No valid input provided!", 400

    # Generate QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(qr_data)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white")

    qr_code_filename = f"{filename or 'link_qr'}.png"
    qr_code_path = os.path.join(UPLOAD_FOLDER, qr_code_filename)
    qr_img.save(qr_code_path)

    return render_template("result.html", qr_path=qr_code_path, filename=qr_code_filename)

@app.route("/download/<filename>")
def download(filename):
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return "File not found!", 404

if __name__ == "__main__":
    app.run(debug=True)
