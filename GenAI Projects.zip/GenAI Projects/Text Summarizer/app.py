import os
from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
import openai
import tempfile

# Load environment variables
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# Initialize Flask app
app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "uploads"
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# Function to count words
def count_words(text):
    return len(text.split())

# Function to generate summary and title using ChatGPT
def generate_summary_and_title(input_text):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an assistant skilled in summarizing and generating titles."},
                {
                    "role": "user",
                    "content": f"Summarize the following text to exactly 100 words and generate a 5–10 word title:\n\n{input_text}",
                },
            ],
        )
        result = response.choices[0].message["content"]
        lines = result.split("\n", 1)
        title = lines[0].strip() if len(lines) > 0 else "No Title"
        summary = lines[1].strip() if len(lines) > 1 else "No Summary"
        return title, summary
    except Exception as e:
        return "Error generating title", f"Error: {e}"

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        input_text = ""
        file = request.files.get("file")

        if file:
            # Handle file upload
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)
            with open(filepath, "r", encoding="utf-8") as f:
                input_text = f.read()
        else:
            # Handle pasted text
            input_text = request.form.get("text")

        if not input_text.strip():
            return jsonify({"error": "No input text provided"}), 400

        word_count = count_words(input_text)
        summary, title = generate_summary_and_title(input_text)
        summary_word_count = count_words(summary)

        # Save summary for download
        temp_summary_path = tempfile.mktemp(suffix=".txt")
        with open(temp_summary_path, "w", encoding="utf-8") as f:
            f.write(summary)

        return jsonify(
            {
                "word_count": word_count,
                "title": title,
                "summary": summary,
                "summary_word_count": summary_word_count,
                "download_path": temp_summary_path,
            }
        )
    return render_template("index.html")

@app.route("/download", methods=["GET"])
def download():
    path = request.args.get("path")
    if os.path.exists(path):
        return send_file(path, as_attachment=True)
    return "File not found", 404

if __name__ == "__main__":
    app.run(debug=True)
