from flask import Flask, render_template, request, send_file
from werkzeug.utils import secure_filename
import os
from PyPDF2 import PdfReader
import easyocr
import tempfile

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize EasyOCR reader
reader = easyocr.Reader(['en'])

def extract_text_from_pdf(file_path):
    """Extract text from PDF using PyPDF2."""
    reader = PdfReader(file_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text

def extract_text_from_image(file_path):
    """Extract text from image using EasyOCR."""
    result = reader.readtext(file_path, detail=0)  # Extract text as a list of strings
    return "\n".join(result)

@app.route('/', methods=['GET', 'POST'])
def index():
    extracted_text = None
    if request.method == 'POST':
        file = request.files['file']
        if file:
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            # Process the file based on its type
            if filename.lower().endswith('.pdf'):
                extracted_text = extract_text_from_pdf(file_path)
            else:
                extracted_text = extract_text_from_image(file_path)

            # Save the extracted text to a temporary file for downloading
            with open(os.path.join(tempfile.gettempdir(), "extracted_text.txt"), "w", encoding="utf-8") as f:
                f.write(extracted_text)

    return render_template('index.html', extracted_text=extracted_text)

@app.route('/download', methods=['GET'])
def download():
    """Serve the extracted text as a downloadable file."""
    file_path = os.path.join(tempfile.gettempdir(), "extracted_text.txt")
    return send_file(file_path, as_attachment=True, download_name="extracted_text.txt")

if __name__ == '__main__':
    app.run(debug=True)
