import os
from flask import Flask, render_template, request, send_file
from rembg import remove
from PIL import Image
import io

app = Flask(__name__)
UPLOAD_FOLDER = 'static/processed'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_image():
    if 'image' not in request.files:
        return "No file uploaded", 400

    file = request.files['image']
    if file.filename == '':
        return "No file selected", 400

    # Save original image to be displayed
    img_path = os.path.join(UPLOAD_FOLDER, 'original_image.jpg')
    file.save(img_path)

    # Process the image to remove the background
    img = Image.open(file.stream).convert("RGBA")
    img_no_bg = remove(img)

    # Save the processed image (background removed)
    buffer = io.BytesIO()
    img_no_bg.save(buffer, format='PNG')
    buffer.seek(0)

    output_path = os.path.join(UPLOAD_FOLDER, 'output.png')
    with open(output_path, 'wb') as f:
        f.write(buffer.getbuffer())

    return render_template('index.html', processed_image='processed/output.png', original_image='processed/original_image.jpg')

@app.route('/download', methods=['POST'])
def download_image():
    format_choice = request.form.get('format')
    output_path = os.path.join(UPLOAD_FOLDER, 'output.png')

    if format_choice == 'JPEG':
        output = io.BytesIO()
        Image.open(output_path).convert('RGB').save(output, format='JPEG')
        output.seek(0)
        return send_file(output, as_attachment=True, download_name="output.jpg", mimetype='image/jpeg')
    elif format_choice == 'PNG':
        return send_file(output_path, as_attachment=True, download_name="output.png", mimetype='image/png')
    else:
        return "Invalid format selected", 400

if __name__ == "__main__":
    app.run(debug=True)
