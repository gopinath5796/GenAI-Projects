let mediaRecorder;
let audioChunks = [];

// Handle record button
document.getElementById("record-btn").addEventListener("click", () => {
    navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
        mediaRecorder = new MediaRecorder(stream);
        mediaRecorder.start();

        mediaRecorder.ondataavailable = event => {
            audioChunks.push(event.data);
        };

        mediaRecorder.onstop = () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
            audioChunks = [];
            const formData = new FormData();
            formData.append("audio", audioBlob);

            fetch("/transcribe", { method: "POST", body: formData })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const confirmed = confirm(`Did you mean: "${data.text}"?`);
                        if (confirmed) sendToChatGPT(data.text);
                    } else {
                        alert(data.error);
                    }
                });
        };

        setTimeout(() => {
            mediaRecorder.stop();
        }, 5000); // Record for 5 seconds
    });
});

// Handle text search button
document.getElementById("search-btn").addEventListener("click", () => {
    const text = document.getElementById("text-input").value;
    if (text.trim()) sendToChatGPT(text);
});


function sendToChatGPT(text) {
    fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById("output").innerText = data.reply;
            } else {
                alert(data.error);
            }
        });
}
