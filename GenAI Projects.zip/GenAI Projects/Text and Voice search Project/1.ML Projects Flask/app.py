from flask import Flask, render_template, request, jsonify
import speech_recognition as sr
from pydub import AudioSegment
import openai

app = Flask(__name__)

# Configure OpenAI API key
openai.api_key = "sk-45IP-VkQDilefrnypJShbdY8V8RHqrgI8TSptnR7C6T3BlbkFJnSfsZ_LmNi7EO3GD36XGnnVngFgRtMClRc6m5EVdwA"

@app.route("/")
def index():
    return render_template('index.html')  # Renders the main HTML page

@app.route("/transcribe", methods=["POST"])
def transcribe_audio():
    try:
        # Receive the audio file from the frontend
        audio_file = request.files['audio']
        temp_original_path = 'temp_audio_original'
        temp_pcm_path = 'temp_audio.wav'

        # Save the uploaded file
        audio_file.save(temp_original_path)

        # Convert to PCM WAV format using PyDub
        sound = AudioSegment.from_file(temp_original_path)
        sound.export(temp_pcm_path, format='wav')

        # Recognize speech using SpeechRecognition
        recognizer = sr.Recognizer()
        with sr.AudioFile(temp_pcm_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)

        return jsonify({"success": True, "text": text})
    except sr.UnknownValueError:
        return jsonify({"success": False, "error": "Could not understand audio"}), 400
    except sr.RequestError as e:
        return jsonify({"success": False, "error": str(e)}), 500
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/search", methods=["POST"])
def search():
    """
    Handles both text and voice input to query ChatGPT.
    If text is provided, it queries directly.
    If voice is provided, it transcribes and confirms before querying.
    """
    try:
        # Get input type and data
        input_type = request.json.get("input_type")  # 'text' or 'voice'
        user_input = request.json.get("input")

        if input_type == "text":
            # Directly search ChatGPT with text
            return query_chatgpt(user_input)
        elif input_type == "voice":
            # Voice input requires transcription and confirmation
            transcribed_text = transcribe_audio_data(user_input)
            return jsonify({"success": True, "transcribed_text": transcribed_text})
        else:
            return jsonify({"success": False, "error": "Invalid input type"}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("text")
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": user_input}],
        )
        reply = response.choices[0].message["content"]
        return jsonify({"success": True, "reply": reply})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


def query_chatgpt(user_input):
    """
    Queries the ChatGPT API with the provided input.
    """
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": user_input}],
        )
        reply = response.choices[0].message["content"]
        return jsonify({"success": True, "reply": reply})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

def transcribe_audio_data(audio_file):
    """
    Helper function to transcribe audio data to text.
    """
    try:
        temp_original_path = 'temp_audio_original'
        temp_pcm_path = 'temp_audio.wav'

        # Save the uploaded file
        audio_file.save(temp_original_path)

        # Convert to PCM WAV format using PyDub
        sound = AudioSegment.from_file(temp_original_path)
        sound.export(temp_pcm_path, format='wav')

        # Recognize speech using SpeechRecognition
        recognizer = sr.Recognizer()
        with sr.AudioFile(temp_pcm_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)

        return text
    except Exception as e:
        raise ValueError("Audio transcription failed: " + str(e))

if __name__ == "__main__":
    app.run(debug=True)
