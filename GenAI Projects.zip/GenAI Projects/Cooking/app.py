from flask import Flask, request, render_template, redirect, url_for
import os
from keras.models import load_model
from keras.preprocessing.image import load_img, img_to_array
import numpy as np
import openai
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")




# Initialize Flask app
app = Flask(__name__)

# Configuration
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.secret_key = 'your_secret_key'

# Load pre-trained model
model = load_model('Vegetable_model.h5')
labels = [
    'Bean', 'Bitter_Gourd', 'Bottle_Gourd', 'Brinjal', 'Broccoli',
    'Cabbage', 'Capsicum', 'Carrot', 'Cauliflower', 'Cucumber',
    'Papaya', 'Potato', 'Pumpkin', 'Radish', 'Tomato'

]


def preprocess_image(image_path):
    img = load_img(image_path, target_size=(150, 150))
    img_array = img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array

def identify_vegetables(image_path):
    processed_image = preprocess_image(image_path)
    predictions = model.predict(processed_image)
    top_indices = np.argsort(predictions[0])[-4:]  # Top 3 predictions
    vegetables = [labels[idx] for idx in top_indices]
    return vegetables

def generate_recipes(vegetables):
    import openai
    openai.api_key = os.getenv("OPENAI_API_KEY")  # Ensure your API key is loaded from the environment

    prompt = f"Suggest 10 recipes using the following vegetables: {', '.join(vegetables)}. Provide only the names of the recipes."

    # Use the ChatCompletion API with the newer models
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # Change to "gpt-4" if higher quality is needed
        messages=[
            {"role": "system", "content": "You are a culinary expert who suggests recipes."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=200,
        n=1
    )

    # Extract the recipe names from the response
    recipes = response["choices"][0]["message"]["content"].strip().split('\n')
    return recipes


def get_recipe_steps(recipe_name):
    import openai
    openai.api_key = os.getenv("OPENAI_API_KEY")  # Ensure your API key is loaded from the environment

    prompt = f"Provide step-by-step cooking instructions for {recipe_name}."

    # Use the ChatCompletion API with the newer models
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # Use "gpt-4" if higher quality is needed
        messages=[
            {"role": "system", "content": "You are a culinary expert who provides detailed cooking instructions."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=500,
        n=1
    )

    # Extract the cooking steps from the response
    cooking_steps = response["choices"][0]["message"]["content"].strip()
    return cooking_steps



@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Handle image upload
        if 'file' in request.files:
            file = request.files['file']
            if file.filename != '':
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
                file.save(file_path)

                # Identify vegetables
                vegetables = identify_vegetables(file_path)

                # Generate recipes
                recipes = generate_recipes(vegetables)
                return render_template('result.html', vegetables=vegetables, recipes=recipes, image_path=file_path)
        # Handle text input for vegetable names
        elif 'vegetables' in request.form:
            vegetables_text = request.form.get('vegetables')
            if vegetables_text:
                vegetables = vegetables_text.split(',')
                recipes = generate_recipes(vegetables)
                return render_template('result.html', vegetables=vegetables, recipes=recipes)
    return render_template('index.html')

@app.route('/recipe', methods=['POST'])
def recipe():
    recipe_name = request.form.get('recipe_name')
    if recipe_name:
        steps = get_recipe_steps(recipe_name)
        return render_template('recipe.html', recipe_name=recipe_name, steps=steps)
    return redirect(url_for('index'))

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)
