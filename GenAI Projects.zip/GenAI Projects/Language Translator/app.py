import openai
from flask import Flask, render_template, request, jsonify
import pyttsx3

# Set your OpenAI API key
openai.api_key = 'sk-45IP-VkQDilefrnypJShbdY8V8RHqrgI8TSptnR7C6T3BlbkFJnSfsZ_LmNi7EO3GD36XGnnVngFgRtMClRc6m5EVdwA'

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/detect_language', methods=['POST'])
def detect_language():
    text = request.form.get('text')
    if not text:
        return jsonify({"error": "No text provided"}), 400

    try:
        # Using OpenAI to detect the language
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a language detection assistant."},
                {"role": "user", "content": f"What language is this text in? '{text}'"}
            ]
        )
        language = response['choices'][0]['message']['content']
        return jsonify({"language": language})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/translate', methods=['POST'])
def translate_text():
    text = request.form.get('text')
    target_language = request.form.get('target_language')
    if not text or not target_language:
        return jsonify({"error": "Text or target language not provided"}), 400

    try:
        # Use OpenAI to translate the text
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a translation assistant."},
                {"role": "user", "content": f"Translate the following text to {target_language}: '{text}'"}
            ]
        )
        translated_text = response['choices'][0]['message']['content']
        return jsonify({"translated_text": translated_text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/speak', methods=['POST'])
def speak_text():
    text = request.form.get('text')
    if not text:
        return jsonify({"error": "No text provided"}), 400

    try:
        # Initialize text-to-speech engine
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
