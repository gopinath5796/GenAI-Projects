from yolov5.detect import run as detect_with_yolov5
from torchvision import models, transforms
from PIL import Image
import torch
from transformers import VisionEncoderDecoderModel, ViTImageProcessor, AutoTokenizer

# Load pre-trained AlexNet model
alexnet = models.alexnet(pretrained=True)

# Load class labels
with open('imagenet_classes.txt') as f:
    classes = [line.strip() for line in f.readlines()]

# Load pre-trained ViT-GPT2 image captioning model
model = VisionEncoderDecoderModel.from_pretrained("nlpconnect/vit-gpt2-image-captioning")
feature_extractor = ViTImageProcessor.from_pretrained("nlpconnect/vit-gpt2-image-captioning")
tokenizer = AutoTokenizer.from_pretrained("nlpconnect/vit-gpt2-image-captioning")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

def detect_classify_caption(image_path):
    # Step 1: Object Detection with YOLOv5
    results = detect_with_yolov5(weights='yolov5s.pt', source=image_path, exist_ok=True)
    
    # Step 2: Image Classification with AlexNet
    img = Image.open(image_path)
    transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )
    ])
    img_t = transform(img)
    batch_t = torch.unsqueeze(img_t, 0)
    alexnet.eval()
    out = alexnet(batch_t)
    _, indices = torch.sort(out, descending=True)
    percentage = torch.nn.functional.softmax(out, dim=1)[0] * 100
    top_predictions = [(classes[idx], percentage[idx].item()) for idx in indices[0][:10]]
    
    # Step 3: Image Captioning with ViT-GPT2
    pixel_values = feature_extractor(images=[img], return_tensors="pt").pixel_values.to(device)
    max_length = 16
    num_beams = 4
    gen_kwargs = {"max_length": max_length, "num_beams": num_beams}
    output_ids = model.generate(pixel_values, **gen_kwargs)
    preds = tokenizer.batch_decode(output_ids, skip_special_tokens=True)
    preds = [pred.strip() for pred in preds]

    return results, top_predictions, preds

# Example usage
image_path = 'C:\\Users\\sony\\yolov5\\data\\images\\image-0.jpg'
object_detection_results, classification_results, caption_predictions = detect_classify_caption(image_path)
print("Object Detection Results:", object_detection_results)
print("Image Classification Results:", classification_results)
print("Image Captioning Predictions:", caption_predictions)
