from flask import Flask, render_template, request, redirect, url_for
from detect_classify_caption import detect_classify_caption

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'file' not in request.files:
            return redirect(request.url)
        
        file = request.files['file']
        
        # If user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            return redirect(request.url)

        # If file exists and is allowed, call the detect_classify_caption function
        if file:
            # Save the file temporarily
            image_path = 'temp.jpg'
            file.save(image_path)

            # Process the image
            object_detection_results, classification_results, caption_predictions = detect_classify_caption(image_path)

            return render_template('result.html', 
                                   object_detection_results=object_detection_results,
                                   classification_results=classification_results,
                                   caption_predictions=caption_predictions)

@app.route('/download')
def download():
    # Here you can provide a download link to download the results
    # For simplicity, let's just redirect to the homepage
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=8000)

